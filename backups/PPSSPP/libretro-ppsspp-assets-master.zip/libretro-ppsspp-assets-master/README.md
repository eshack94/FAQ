# libretro-ppsspp-assets
These are the asset files required for using libretro-ppsspp. They should be placed in the libretro system/PPSSPP directory.
